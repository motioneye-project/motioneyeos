/* Table mapping between kernel fpregset and GDB register cache.
   Copyright 2007 Free Software Foundation, Inc.

   This file is part of GDB.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street - Fifth Floor, Boston, MA
   02110-1301, USA.  */


#include "xtensa-regmap.h"

#define XTENSA_ELF_XTREG_SIZE	28

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   44, 176,  24,  24,  4, -1, 0x020c, "scompare1" },
  {   45, 180,   0,   0,  4, -1, 0x0210, "acclo" },
  {   46, 184,   4,   4,  4, -1, 0x0211, "acchi" },
  {   47, 188,   8,   8,  4, -1, 0x0220, "m0" },
  {   48, 192,  12,  12,  4, -1, 0x0221, "m1" },
  {   49, 196,  16,  16,  4, -1, 0x0222, "m2" },
  {   50, 200,  20,  20,  4, -1, 0x0223, "m3" },
  { 0 }
};

